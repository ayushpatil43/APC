n=10
for i in range(0,n+1,2):
    print(i)