i=5
f=1
sum=0
#for i in range(0,n+1):
for n in range(1,i+1):
        f*=n
        sum+=1/f

print(sum)
