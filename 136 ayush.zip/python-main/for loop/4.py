n = 8
a = n * n  
i = 1

for _ in range(100):   
    if i > a:
        break
    else:
        print(i)
        i *= 2 
