#int
x=50;
print(x);
print(type(x));

#float
x=0.5
print(x)
print(type(x))

#string
x="Hello World"
print(x)
print(type(x))

#List
x=["suyog","pratik","sandesh"]
print(x)
print(type(x))

#tuple
x=("suyog","pratik","sandesh")
print(x)
print(type(x))

#Boolean
x=True
print(x)
print(type(x))

#complex
x=45J
print(x)
print(type(x))

#Dictionary
x={1:'mango',2:'apple'}
print(x)
print(type(x))
