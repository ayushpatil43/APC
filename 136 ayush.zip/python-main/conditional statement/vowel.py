n=input("Enter a character:")

if (n=='a',n=='e',n=='i',n=='o',n=='u',n=='A',n=='E',n=='I',n=='O',n=='U'):
    print("Character is a vowel.")
else:
    print("character is consonant")
