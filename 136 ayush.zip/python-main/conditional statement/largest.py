num1=int(input("Enter the 1st number:"))
num2=int(input("Enter the 2nd number:"))

if num1 > num2:
    print(num1,"is a greater number than",num2)
else:
    print(num2,"is greater number than",num1)