number=int(input("Enetr a Positive Number :"));
if number > 0:
    print("Number Is Positive.")


if number % 2 == 0:
    print("Number is Even.")
else:
    print("number is Odd")


if number==10:
    print("The enterednumber is 10")
elif number==50:
    print("The entered numbre is 50")
else:
    print("number is 100")
