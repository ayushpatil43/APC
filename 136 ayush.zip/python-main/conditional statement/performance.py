marks=int(input("Enter the percentage of student:"))

if marks>=90:
    print("Excellent Performance.")
elif marks>=80:
    print("Very Good Performance.")
elif marks>=70:
    print("Good Performance.")
elif marks>=60:
    print("Average Performance.")
else:
    print("Poor Perfromance.")