n=int(input("Enter a number"))

if n == 0 :
    print("Number is zero")
else:
    print("NUmber is Non-Zero")