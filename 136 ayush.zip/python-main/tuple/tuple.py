t1=()
t1=tuple(input("enter the elemet:"))
print("tuple is:",t1)

t2=list(t1)
print("conversation of tuple to list is:",t2)

print("first element of tuple:",t1[0])

print("no. of a in tuple:",t1.count("a"))
