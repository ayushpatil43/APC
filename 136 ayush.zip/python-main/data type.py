
# DATA TYPE 


A ="I M ENGG STUDENT AT DYP"
print(A)
print(type(A))

I = 355
print(I)
print(type(I))

K = 2.14
print(K)
print(type(K))

C = 3J
print(C)
print(type(C))

B =True
print(B)
print(type(B))

X =["APPLE " "CHERRY " " KERRY " ' MANGO']
print(X)
print(type(X))

Y=( "APPLE " ,"CHERRY " ," KERRY " ,' MANGO')

print(Y)
print(type(Y))

Z={1:'APPLE',2:'CHERRY'}
print(Z)
print(type(Z))

