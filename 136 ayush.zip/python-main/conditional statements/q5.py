n=int(input("enter the marks in percentage : "))


if n >= 90:
    print("Excellent performance")
elif n >= 80:
    print("Very Good performance")
elif n >= 70:
    print("Good performance")
elif n >= 60:
    print("Average performance")
else:
    print("poor performnce")