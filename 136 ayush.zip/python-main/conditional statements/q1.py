n=int(input("enter the number"))


if n == 0:
    print("number is zero")
else:
    print("number is non zero")


