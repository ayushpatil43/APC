n=int(input("enter the number"))


if n > 0:
    print("number is positive")
elif n < 0:
    print("number is negative")