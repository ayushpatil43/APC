n1=int(input("enter the first number"))
n2=int(input("enter the second number"))

if n1>n2:
    print("first number is largest")
else:
    print("second number is largest")