x=input("enter the character : ")


if (x == 'a' or x == 'e' or x == 'i' or x == 'o' or x == 'u'):
    print("number is vowel")
else:
    print("number is consonant")