file = open("demo.txt","r")
print(file.read())
file.close()