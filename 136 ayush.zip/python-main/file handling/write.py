file = open("demo.txt","w")
file.write("demo file\n")
file.write("writing a file\n")
file.close()

