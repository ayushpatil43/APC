file = open("demo.txt","r")
print(file.readlines())
file.close()