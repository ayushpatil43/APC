file = open("demo.txt","a")
file.write("demo file\n")
file.write("appending a file\n")
file.close()