with open("demo.txt","r") as file:
     print(file.read())