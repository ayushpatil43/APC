n=int(input("Enter the number"))
i=2
while i <= n:
    print(i,end=' ')
    i+=2
    