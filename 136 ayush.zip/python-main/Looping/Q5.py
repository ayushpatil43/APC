num=int(input("Enter the number"))

while i<=n:
    print("Numbers are-")
