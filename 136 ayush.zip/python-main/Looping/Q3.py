n=int(input("Enter the number"))
i=1
while i <= n:
    print("Odd numbers:",i,end=' ')
    i+=2
    