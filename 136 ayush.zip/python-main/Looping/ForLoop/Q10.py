n = int(input("Enter the value of n: "))

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

for i in range(n, 0, -1):  
    print(alphabet[:i])   
