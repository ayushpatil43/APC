n = int(input("Enter the value of n: "))

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

for i in range(1, n + 1):
    print(alphabet[:i])
