n=int(input("Enter the number"))
sum=0
i=1
while i <= n:
    sum+=i
    i+=1

print("Sum of namtural number up to",n,"is:",sum)