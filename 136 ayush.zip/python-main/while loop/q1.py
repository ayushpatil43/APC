n=int(input("enter the number"))
i=1
while i <= n:
    print(i,end=' ')
    i+=1