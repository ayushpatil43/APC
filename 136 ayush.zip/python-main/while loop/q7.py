i=int(input("enter the number"))

while i >=1:
    print(i,end=' ')
    i-=1