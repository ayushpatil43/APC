n=int(input("enter the number"))
i=1
print("odd numbers :")
while i <= n:
    print(i,end=' ')
    i+=2