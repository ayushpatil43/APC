n=int(input("enter the number"))
sum=0
i=2
while i <= n:
    sum+=i
    i+=2

print(sum)