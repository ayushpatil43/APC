n=int(input("enter the number"))
i=0
print("even numbers :")
while i <= n:
    print(i,end=' ')
    i+=2