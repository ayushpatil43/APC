import numpy as np

a = np.array([1, 2, 3, 4])
b = np.array([10, 20, 30, 40])

print(a + b)  
print(a * b)  

print(np.mean(a))   
print(np.max(b))    
print(np.sum(a))    
