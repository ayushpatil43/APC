class student:
    def display(self):
        print("this is class example")

s1 = student()
s1.display()
