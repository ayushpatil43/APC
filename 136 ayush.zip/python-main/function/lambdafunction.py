square = lambda x:x*x
print("square of 5 is :",square(5))

cube = lambda x:x*x*x
print("cube of 5 is :",cube(5))

add = lambda x, y: x + y
print("addition is :",add(5,4))  

multiply = lambda x, y: x * y
print("multiplication is :",multiply(4, 5))  
