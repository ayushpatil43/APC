def add(a,b):
    return a+b

def sub(a,b):
    return a-b

def multi(a,b):
    return a*b

def div(a,b):
    return a/b

result=add(10,20)
print("sum :",result)

result=sub(30,20)
print("subtraction :",result)

result=multi(50,20)
print("multplication :",result)

result=div(100,20)
print("division :",result)