from package import add

result = add(10, 20)
print(f"The sum is: {result}")